### Xiang Zhang  (zxiang4@binghamton.edu)
### Wenchen Li  (wli100@binghamton.edu)
####  Not Tested in bingsuns

Sorry to upload this assingment late, because I find there is a bug for deleteNList

the previous type assignment named it as delete 'Term'. And I forgot to change the deleteNMTerm to deleteNMList.
thank you
