//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cssample4.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CS460ATYPE                  129
#define ID_INC_X                        32771
#define ID_VIEW_SMOOTH                  32771
#define ID_INC_Y                        32774
#define ID_VIEW_LIGHT_YDEC              32774
#define ID_DEC_Y                        32775
#define ID_VIEW_LIGHT_YINC              32775
#define ID_DEC_X                        32776
#define ID_VIEW_FLAT                    32776
#define ID_VIEW_ORTHO                   32777
#define ID_VIEW_PERSPECTIVE             32778
#define ID_VIEW_ZOOMOUT                 32779
#define ID_VIEW_WIREFRAME               32779
#define ID_VIEW_ZOOMIN                  32780
#define ID_VIEW_FILLED                  32780
#define ID_LEVER_ROTATION               32781
#define ID_CAMERA_ROLL_UP               32782
#define ID_CAMERA_ROLL_DOWN             32783
#define ID_CAMERA_PITCH_UP              32784
#define ID_CAMERA_PITCH_DOWN            32785
#define ID_CAMERA_YAW_UP                32786
#define ID_CAMERA_YAW_DOWN              32787
#define ID_CAMERA_SLIDE_P               32788
#define ID_CAMERA_SLIDE_N               32789
#define ID_AS4_SELECT_1                 32790
#define ID_AS4_SELECT_2                 32791
#define ID_AS4_SELECT_4                 32792
#define ID_AS4_SELECT_3                 32793
#define ID_AS4_X_INC                    32794
#define ID_AS4_X_DEC                    32795
#define ID_AS4_Y_INC                    32796
#define ID_AS4_Y_DEC                    32797
#define ID_AS4_Z_INC                    32798
#define ID_AS4_Z_DEC                    32799
#define ID_VIEW_TEXTURE_ENABLE          32800
#define ID_VIEW_TEXTURE_DISABLE         32801
#define ID_VIEW_POS_INCZ                32802
#define ID_VIEW_POS_DECZ                32803

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32804
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
