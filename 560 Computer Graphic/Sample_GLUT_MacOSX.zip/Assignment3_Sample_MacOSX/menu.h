
void mouse(int button, int state, int x, int y);// call when left/right/middle click.
void motion( int x, int y );// call when mouse motion
void CreateMenu(void);  // creat menu 
void MenuItemClicked(int Value); // creat menu
void SubMenuItemClicked(int Value);// creat sub-menu
void specialKey(int key, int x, int y);
