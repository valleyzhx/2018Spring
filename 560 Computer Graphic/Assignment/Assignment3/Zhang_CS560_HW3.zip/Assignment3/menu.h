
void CreateMenu(void);  // creat menu 
void MenuItemClicked(int Value); // creat menu
void SubMenuItemClicked(int Value);// creat sub-menu
void specialKey(int key, int x, int y);
