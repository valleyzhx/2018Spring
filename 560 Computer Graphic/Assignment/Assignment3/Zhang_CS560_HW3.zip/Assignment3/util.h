#include <stdio.h>
#include <iostream>
#include <math.h>
#include <GLUT/GLUT.h>
#include <vector>
#include <assert.h>
#include <OpenGL/gl.h>


