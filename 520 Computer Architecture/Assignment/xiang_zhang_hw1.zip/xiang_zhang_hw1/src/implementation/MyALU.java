/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation;

import utilitytypes.EnumOpcode;
import utilitytypes.Operand;

/**
 * The code that implements the ALU has been separates out into a static
 * method in its own class.  However, this is just a design choice, and you
 * are not required to do this.
 * 
 * @author 
 */
public class MyALU {
    static int execute(EnumOpcode opcode, int input1, int input2, int oper0) {
        int result = 0;
        boolean hasResult = true;
        // Implement code here that performs appropriate computations for
        // any instruction that requires an ALU operation.  See
        // EnumOpcode.
        switch (opcode){
            case ADD:
                //System.out.println("Executing ("+input1+" ADD " +input2 + ")");
                result = input1 + input2;
                break;
            case SUB:
                //System.out.println("Executing SUB opcode:");
                result = input1 - input2;
                break;
            case AND:
                //System.out.println("Executing ("+input1+" AND " +input2 + ")");
                result = input1 & input2;
                break;
            case OR:
                //System.out.println("Executing ("+input1+" OR " +input2 + ")");
                result = input1 | input2;
                break;

            //>> is arithmetic shift right, >>> is logical shift right.
            case SHL://logical shift left (inserts zeros on the right)
                //System.out.println("Executing ("+input1+" SHL " +input2 + ")");
                result = input1 << input2;
                break;
            case ASR://arithmetic shift right (replicates sign bit)
                //System.out.println("Executing ("+input1+" ASR " +input2 + ")");
                result = input1 >> input2;
                break;
            case LSR://logical shift right (inserts zeros on the left)
                //System.out.println("Executing ("+input1+" LSR " +input2 + ")");
                result = input1 >>> input2;
                break;
            case XOR:
                //System.out.println("Executing ("+input1+" XOR " +input2 + ")");
                result = input1 ^ input2;
                break;
            case ROL:
                //System.out.println("Executing ("+input1+" ROL " +input2 + ")");
                result = Integer.rotateLeft(input1, input2);
                break;
            case ROR:
                //System.out.println("Executing ("+input1+" ROR " +input2 + ")");
                result = Integer.rotateRight(input1, input2);
                break;
            case MULS:
                //System.out.println("Executing ("+input1+" MULS " +input2 + ")");
                result = input1*input2;
                break;
            case MULU:
                //System.out.println("Executing ("+input1+" MULU " +input2 + ")");
                result = input1*input2;
                break;
            case DIVS:
                //System.out.println("Executing ("+input1+" DIVS " +input2 + ")");
                result = input1/input2;
                break;
            case DIVU:
                //System.out.println("Executing ("+input1+" DIVU " +input2 + ")");
                result = Integer.divideUnsigned(input1,input2);
                break;
            case MOVC:
                //System.out.println("Executing ("+input1+" MOVC " +input2 + ")");
                result = input1;
                break;
            case OUT:
                result = oper0;
                //System.out.println("Executing OUT opcode:");
                System.out.println("@@output:"+result);
                break;
            case CMP:
                result = input1-input2;
                //System.out.println("CMP:"+input1+"-"+input2+"="+(input1-input2));

                break;
            case LOAD:
                //System.out.println("Executing LOAD opcode:");
                result = input1+input2;
                break;
            case STORE:
                //System.out.println("Executing STORE opcode:");
                result = input1+input2;
                break;

            default:
                    hasResult = false;
                    break;
        }
        if (hasResult){
            //System.out.println("result = "+result);
        }
        //System.out.println(opcode + " " +oper0 + " " + input1 + " " +input2);

        return result;
    }    
}
