/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation;

import utilitytypes.EnumComparison;
import utilitytypes.IGlobals;
import tools.InstructionSequence;
import java.util.HashMap;

/**
 * As a design choice, some data elements that are accessed by multiple
 * pipeline stages are stored in a common object.
 * 
 * TODO:  Add to this any additional global or shared state that is missing.
 * 
 * @author 
 */
public class GlobalData implements IGlobals {
    public InstructionSequence program;
    public int program_counter = 0;
    public int[] register_file = new int[32];
    public boolean[] register_invalid = new boolean[32];

    @Override
    public void reset() {
        program_counter = 0;
        register_file = new int[32];
    }
    
    
    // Other global and shared variables here....
    // add the program_counter
    public boolean isHalt = false;

    //memory
    public int[] memory_arr = new int[1024];

    // Next PC to fetch if Decode not stalled and/or branch resolved not taken
    public int next_counter_nobranch = 0;
    // Next PC to fetch if Decode not stalled and branch resolved taken
    public int next_counter_takenbranch = 0;

    //public  boolean isBranching = false; should contains WAITING TAKEN NOT_TAKEN status

    // Names of branch states and signals
    public static enum EnumBranchState {
        NULL, WAITING, TAKEN, NOT_TAKEN
    }

    public EnumBranchState current_branch_state = EnumBranchState.NULL;

    public EnumBranchState next_branch_fetch_state = EnumBranchState.NULL;

    public EnumBranchState next_branch_decode_state = EnumBranchState.NULL;

    // public  int getMemory();

}
