/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package implementation;

import implementation.AllMyLatches.*;
import utilitytypes.EnumComparison;
import utilitytypes.EnumOpcode;
import baseclasses.InstructionBase;
import baseclasses.PipelineRegister;
import baseclasses.PipelineStageBase;
import utilitytypes.LabelTarget;
import utilitytypes.Operand;
import voidtypes.VoidLatch;
import baseclasses.CpuCore;

/**
 * The AllMyStages class merely collects together all of the pipeline stage 
 * classes into one place.  You are free to split them out into top-level
 * classes.
 * 
 * Each inner class here implements the logic for a pipeline stage.
 * 
 * It is recommended that the compute methods be idempotent.  This means
 * that if compute is called multiple times in a clock cycle, it should
 * compute the same output for the same input.
 * 
 * How might we make updating the program counter idempotent?
 * 
 * @author
 */
public class AllMyStages {
    /*** Fetch Stage ***/
    static class Fetch extends PipelineStageBase<VoidLatch,FetchToDecode> {
        public Fetch(CpuCore core, PipelineRegister input, PipelineRegister output) {
            super(core, input, output);
        }
        
        @Override
        public String getStatus() {
            // Generate a string that helps you debug.
            return super.getStatus();
        }

        @Override
        public void compute(VoidLatch input, FetchToDecode output) {
            GlobalData globals = (GlobalData)core.getGlobalResources();
            int pc = globals.program_counter;
            // Fetch the instruction
            InstructionBase ins = globals.program.getInstructionAt(pc);
            if (ins.isNull()) {
                // Fetch is working on no instruction at no address
                setActivity("----: NULL");
                // Nothing more to do.
                return;
            }
            // Do something idempotent to compute the next program counter.
            
            // Don't forget branches, which MUST be resolved in the Decode
            // stage.  You will make use of global resources to commmunicate
            // between stages.
            
            // Your code goes here...


            // Also don't do anything if we're stalled waiting on branch
            // resolution.
            if (globals.current_branch_state != GlobalData.EnumBranchState.NULL) {
                // Fetch is waiting on branch resolution
                setActivity("----: BRANCH-BUBBLE");
                // Since we're stalled, nothing more to do.
                return;
            }


            //++ line number
            globals.next_counter_nobranch = pc + 1;

            if (ins.getOpcode().isBranch()){// bra instruction: set the branch
                globals.next_branch_fetch_state = GlobalData.EnumBranchState.WAITING;
            }

            output.setInstruction(ins);
        }
        
        @Override
        public boolean stageWaitingOnResource() {
            // Hint:  You will need to implement this for when branches
            // are being resolved.

            return false;
        }
        
        
        /**
         * This function is to advance state to the next clock cycle and
         * can be applied to any data that must be updated but which is
         * not stored in a pipeline register.
         */
        @Override
        public void advanceClock() {
            // Hint:  You will need to implement this help with waiting
            // for branch resolution and updating the program counter.
            // Don't forget to check for stall conditions, such as when
            // nextStageCanAcceptWork() returns false.
            if (nextStageCanAcceptWork()){
                //if waiting for resolving
                GlobalData globals = (GlobalData)core.getGlobalResources();
                if (globals.current_branch_state == GlobalData.EnumBranchState.WAITING){
                    //check the decode state, if get the resolution
                    if (globals.next_branch_decode_state != GlobalData.EnumBranchState.NULL){
                        if (globals.next_branch_decode_state == GlobalData.EnumBranchState.TAKEN){
                            //take the branch
                            globals.program_counter = globals.next_counter_takenbranch;
                        }else if (globals.next_branch_decode_state == GlobalData.EnumBranchState.NOT_TAKEN){
                            globals.program_counter = globals.next_counter_nobranch;
                        }
                        //reset the temp counters because the decode got resolution yet
                        globals.next_branch_decode_state = GlobalData.EnumBranchState.NULL;
                        globals.current_branch_state = GlobalData.EnumBranchState.NULL;
                    }

                }else {// NOT WAITING (not branch)
                    if (globals.next_branch_fetch_state != GlobalData.EnumBranchState.NULL) {
                        // Commit the new state
                        globals.current_branch_state = globals.next_branch_fetch_state;

                        // Clear the signal to change the state
                        globals.next_branch_fetch_state = GlobalData.EnumBranchState.NULL;
                    }else {
                        globals.program_counter = globals.next_counter_nobranch;
                    }
                }

            }
        }
    }

    
    /*** Decode Stage ***/
    static class Decode extends PipelineStageBase<FetchToDecode,DecodeToExecute> {
        public Decode(CpuCore core, PipelineRegister input, PipelineRegister output) {
            super(core, input, output);
        }
        public boolean shouldHall;
        
        @Override
        public boolean stageWaitingOnResource() {
            // Hint:  You will need to implement this to deal with 
            // dependencies.

            return shouldHall;
        }
        

        @Override
        public void compute(FetchToDecode input, DecodeToExecute output) {
            InstructionBase ins = input.getInstruction();
            
            // You're going to want to do something like this:
            
            // VVVVV LOOK AT THIS VVVVV
            ins = ins.duplicate();
            // ^^^^^ LOOK AT THIS ^^^^^
            
            // The above will allow you to do things like look up register 
            // values for operands in the instruction and set them but avoid 
            // altering the input latch if you're in a stall condition.
            // The point is that every time you enter this method, you want
            // the instruction and other contents of the input latch to be
            // in their original state, unaffected by whatever you did 
            // in this method when there was a stall condition.
            // By cloning the instruction, you can alter it however you
            // want, and if this stage is stalled, the duplicate gets thrown
            // away without affecting the original.  This helps with 
            // idempotency.
            
            
            
            // These null instruction checks are mostly just to speed up
            // the simulation.  The Void types were created so that null
            // checks can be almost completely avoided.
            if (ins.isNull()) return;
            
            GlobalData globals = (GlobalData)core.getGlobalResources();

            int[] regfile = globals.register_file;
            
            // Do what the decode stage does:
            // - Look up source operands
            // - Decode instruction
            // - Resolve branches
            boolean[] register_invalid = globals.register_invalid;

            EnumOpcode opcode = input.getInstruction().getOpcode();
            Operand src1 = ins.getSrc1();
            Operand src2 = ins.getSrc2();
            Operand oper0 = ins.getOper0();


           //registers.add(FetchToDecode);
            //        registers.add(DecodeToExecute);
            //        registers.add(ExecuteToMemory);
            //        registers.add(MemoryToWriteback);

            output.use0 =output.use1 = output.use2 = false;

            for (int i=1;i<4;i++){
                PipelineRegister register = ((MyCpuCore)core).getPipelineRegister(i);
                String latchtypename = register.getLatchTypeName();
                int regnum = register.getForwardingDestinationRegisterNumber();
                if (regnum < 0) {
                    //System.out.println(latchtypename + " has no target register");
                } else {
                    boolean valid = register.isForwardingResultValid();
                    if (valid) {
                        int value = register.getForwardingResultValue();
                        if (!output.use0&&oper0.isRegister()&&oper0.getRegisterNumber() == regnum){
                            output.source0 = value;
                            output.use0 = true;
                        }
                        if (!output.use1&&src1.isRegister()&&src1.getRegisterNumber() == regnum){
                            output.source1 = value;
                            output.use1 = true;
                        }
                        if (!output.use2&&src2.isRegister()&&src2.getRegisterNumber() == regnum){
                            output.source2 = value;
                            output.use2 = true;
                        }
                       // System.out.println(latchtypename + " has target register R" + regnum + " with value " + value);
                        //break;
                    } else {
//                        System.out.println(latchtypename +
//                                " has target register R" + regnum +
//                                " with no value");
                    }
                }
            }

            shouldHall = false;
            if (oper0.isRegister() && !output.use0 && register_invalid[oper0.getRegisterNumber()]){
                shouldHall = true;
            }
            if (src1.isRegister() && !output.use1 && register_invalid[src1.getRegisterNumber()]){
                shouldHall = true;
            }
            if (src2.isRegister() && !output.use2 && register_invalid[src2.getRegisterNumber()]){
                shouldHall = true;
            }
            if (shouldHall) return;

            if (oper0.isRegister()){
                oper0.lookUpFromRegisterFile(regfile);
                if (opcode.needsWriteback()) register_invalid[oper0.getRegisterNumber()] = true;
            }
            if (src1.isRegister()){
                src1.lookUpFromRegisterFile(regfile);
            }
            if (src2.isRegister()){
                src2.lookUpFromRegisterFile(regfile);
            }

            int source0 = output.use0?output.source0:oper0.getValue();
            int source1 = output.use1?output.source1:src1.getValue();

            if (opcode.isBranch()){
                if (opcode == EnumOpcode.JMP){
                    int address = ins.getLabelTarget().getAddress();
                    if (address>=0) {
                        globals.next_counter_takenbranch = address;
                    }else {
                        globals.next_counter_takenbranch = source0;
                    }
                    globals.next_branch_decode_state = GlobalData.EnumBranchState.TAKEN;
                }else if (opcode == EnumOpcode.BRA){
                    int address = ins.getLabelTarget().getAddress();
                   EnumComparison cmp = ins.getComparison();
                   boolean run = false;
                    if (source0<0){
                        if (cmp == EnumComparison.LT || cmp == EnumComparison.LE){
                            run = true;
                        }
                    }else if (source0==0){
                        if (cmp == EnumComparison.EQ || cmp == EnumComparison.GE || cmp == EnumComparison.LE){
                            run = true;
                        }
                    }else if (source0>0){
                        if (cmp == EnumComparison.GT || cmp == EnumComparison.GE){
                            run = true;
                        }
                    }

                    if (run){
                        //ins.setPCAddress(address);
                        if (address>=0){
                            globals.next_counter_takenbranch = address;
                        }else {
                            globals.next_counter_takenbranch = source1;
                        }
                        globals.next_branch_decode_state = GlobalData.EnumBranchState.TAKEN;
                    }else {
                        globals.next_branch_decode_state = GlobalData.EnumBranchState.NOT_TAKEN;
                    }
                }
            }
            output.setInstruction(ins);
            // Set other data that's passed to the next stage.
        }
    }
    

    /*** Execute Stage ***/
    static class Execute extends PipelineStageBase<DecodeToExecute,ExecuteToMemory> {
        public Execute(CpuCore core, PipelineRegister input, PipelineRegister output) {
            super(core, input, output);
        }

        @Override
        public void compute(DecodeToExecute input, ExecuteToMemory output) {
            InstructionBase ins = input.getInstruction();
            if (ins.isNull()) return;
            EnumOpcode opcode = input.getInstruction().getOpcode();
            int source1 = input.use1?input.source1:ins.getSrc1().getValue();
            int source2 = input.use2?input.source2:ins.getSrc2().getValue();
            int oper0 =   input.use0?input.source0:ins.getOper0().getValue();

            // Fill output with what passes to Memory stage...
            int result = MyALU.execute(opcode, source1, source2, oper0);

            output.execute_result = result;
            output.setInstruction(ins);
            // Set other data that's passed to the next stage.
        }
    }
    

    /*** Memory Stage ***/
    static class Memory extends PipelineStageBase<ExecuteToMemory,MemoryToWriteback> {
        public Memory(CpuCore core, PipelineRegister input, PipelineRegister output) {
            super(core, input, output);
        }

        @Override
        public void compute(ExecuteToMemory input, MemoryToWriteback output) {
            InstructionBase ins = input.getInstruction();
            if (ins.isNull()) return;
            // Access memory...
            EnumOpcode opcode = input.getInstruction().getOpcode();
            GlobalData globals = (GlobalData)core.getGlobalResources();
            Operand source1 = ins.getSrc1();
            Operand source2 = ins.getSrc2();
            Operand oper0 =   ins.getOper0();
            // LOAD’s oper0 is a register target, while STORE’s oper0 is a register source
            output.memory_result = input.execute_result;
            if (opcode == EnumOpcode.LOAD){
                output.memory_result = globals.memory_arr[input.execute_result];
            }else if (opcode == EnumOpcode.STORE){
                globals.memory_arr[input.execute_result] = oper0.getValue();
                //store is not contains in write back
            }
            output.setInstruction(ins);
            // Set other data that's passed to the next stage.
        }
    }
    

    /*** Writeback Stage ***/
    static class Writeback extends PipelineStageBase<MemoryToWriteback,VoidLatch> {
        public Writeback(CpuCore core, PipelineRegister input, PipelineRegister output) {
            super(core, input, output);
        }

        @Override
        public void compute(MemoryToWriteback input, VoidLatch output) {
            InstructionBase ins = input.getInstruction();
            if (ins.isNull()) return;

            // Write back result to register file
            GlobalData globals = (GlobalData)core.getGlobalResources();

            EnumOpcode opcode = input.getInstruction().getOpcode();
            Operand oper0 = ins.getOper0();

            if (opcode.needsWriteback()){

                if (oper0.isRegister()){
                    globals.register_file[oper0.getRegisterNumber()] = input.memory_result;
                    globals.register_invalid[oper0.getRegisterNumber()] = false;
                }

            }else if (opcode == EnumOpcode.HALT) {
                // Stop the simulation
                globals.isHalt = true;
            }

        }
    }
}
