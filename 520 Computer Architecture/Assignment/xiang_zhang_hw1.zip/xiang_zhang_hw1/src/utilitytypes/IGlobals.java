/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilitytypes;

/**
 * Interface for the class that contains any global data used by the 
 * CPU.
 * 
 * @author millerti
 */
public interface IGlobals {
    public void reset();
}
