These "Void" types are used instead of null references.  Using these, we are
able to avoid numerous checks for null references and avoid having to debug
numerous null pointer exceptions.