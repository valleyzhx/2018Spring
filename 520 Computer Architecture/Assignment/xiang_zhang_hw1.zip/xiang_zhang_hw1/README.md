
### CS520 Homework

1. [xiang_zhang_hw1](https://bitbucket.org/xianng/xiang_zhang_hw1/src/HW1/), B00670692
2. complete
3. I have a discussion about the contents of branch solving and memory accessing with Xiaotian, Haizhou and Siyu
